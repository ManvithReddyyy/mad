import java.sql.*;

public class JDBCPreparedCallableDemo {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/testdb";
        String user = "root";
        String password = "sql123";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, user, password);
            System.out.println("Connected to database");

            String insertQuery = "INSERT INTO students (id, name) VALUES (?, ?)";
            PreparedStatement pstmt = con.prepareStatement(insertQuery);

            pstmt.setInt(1, 9);
            pstmt.setString(2, "Prepared_Student");
            pstmt.executeUpdate();

            System.out.println("Inserted using PreparedStatement");

            CallableStatement cstmt = con.prepareCall("{call getStudentById(?)}");
            cstmt.setInt(1, 1);
            ResultSet rs = cstmt.executeQuery();

            while (rs.next()) {
                System.out.println("From procedure -> " + rs.getInt("id") + " | " + rs.getString("name"));
            }

            rs.close();
            cstmt.close();
            pstmt.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}