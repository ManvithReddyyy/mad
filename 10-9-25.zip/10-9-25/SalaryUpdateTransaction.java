import java.sql.*;

public class SalaryUpdateTransaction {
    public static void main(String[] args) {
        // Change these according to your DB setup
        String jdbcURL = "jdbc:mysql://localhost:3306/csea";
        String username = "root";
        String password = "cvr123";

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Load the JDBC driver (optional in newer versions of JDBC)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Get a database connection
            conn = DriverManager.getConnection(jdbcURL, username, password);

            // Disable auto-commit mode to start a transaction
            conn.setAutoCommit(false);

            // SQL query to update salary by 8%
            String sql = "UPDATE employee SET salary = salary * 1.08";
            pstmt = conn.prepareStatement(sql);

            // Execute update
            int rowsUpdated = pstmt.executeUpdate();
            System.out.println(rowsUpdated + " employee' salaries updated.");

            // If everything goes fine, commit transaction
            conn.commit();
            System.out.println("Transaction committed successfully!");

        } catch (Exception e) {
            e.printStackTrace();
            try {
                if (conn != null) {
                    // Rollback in case of any error
                    conn.rollback();
                    System.out.println("Transaction rolled back due to error.");
                }
            } catch (SQLException rollbackEx) {
                rollbackEx.printStackTrace();
            }
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException closeEx) {
                closeEx.printStackTrace();
            }
        }
    }
}
