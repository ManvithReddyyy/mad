import java.sql.*;

public class SimpleJDBCExample {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/csea";
        String user = "root";
        String password = "cvr123";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, user, password);
            System.out.println("Connected to database");

            Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

            String createTable = "CREATE TABLE IF NOT EXISTS students (id INT PRIMARY KEY, name VARCHAR(50))";
            stmt.executeUpdate(createTable);

            // stmt.executeUpdate("INSERT INTO students VALUES (1, 'john')");
            // stmt.executeUpdate("INSERT INTO students VALUES (2, 'dwane')");
            

            ResultSet rs = stmt.executeQuery("SELECT * FROM students");
            while (rs.next()) {
                System.out.println(rs.getInt("id") + " | " + rs.getString("name"));
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

