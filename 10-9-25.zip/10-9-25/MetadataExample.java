import java.sql.*;

public class MetadataExample {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/csea";
        String user = "root";
        String password = "cvr123";
        
        Connection conn = null;
        DatabaseMetaData dbMetaData = null;

        try {
            // Establish connection
            conn = DriverManager.getConnection(url, user, password);

            // Get database metadata
            dbMetaData = conn.getMetaData();

            // Get database version
            System.out.println("Database Product Name: " + dbMetaData.getDatabaseProductName());
            System.out.println("Database Product Version: " + dbMetaData.getDatabaseProductVersion());

            // Get tables in the database
            ResultSet tables = dbMetaData.getTables(null, null, "%", new String[]{"TABLE"});
            System.out.println("\nTables in the database:");
            while (tables.next()) {
                String tableName = tables.getString("TABLE_NAME");
                System.out.println("Table: " + tableName);

                // Get columns for each table
                ResultSet columns = dbMetaData.getColumns(null, null, tableName, "%");
                System.out.println("Columns in table " + tableName + ":");
                while (columns.next()) {
                    String columnName = columns.getString("COLUMN_NAME");
                    String columnType = columns.getString("TYPE_NAME");
                    System.out.println("  Column: " + columnName + " | Type: " + columnType);
                }
                System.out.println();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}