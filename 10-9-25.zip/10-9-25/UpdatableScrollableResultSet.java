import java.sql.*;

public class UpdatableScrollableResultSet {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/csea";
        String user = "root";
        String password = "cvr123";
        
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            conn = DriverManager.getConnection(url, user, password);

            String query = "SELECT id, name FROM students";
            stmt = conn.createStatement(
                ResultSet.TYPE_SCROLL_INSENSITIVE, 
                ResultSet.CONCUR_UPDATABLE
            );
            rs = stmt.executeQuery(query);

            // 1. Move cursor to last row and get total rows
            if (rs.last()) {
                int totalRows = rs.getRow();
                System.out.println("Total rows: " + totalRows);
            }

            // 2. Move cursor to first row explicitly
            rs.first();
            System.out.println("\nFirst row data:");
            System.out.println("ID: " + rs.getInt("id"));
            System.out.println("Name: " + rs.getString("name"));

            // 3. Update the first row's name by appending "_updated"
            String updatedName = rs.getString("name") + "_updated";
            rs.updateString("name", updatedName);
            rs.updateRow();
            System.out.println("Updated first row name to: " + updatedName);

            // 4. Move cursor relatively forward (next row)
            if (rs.relative(1)) {
                System.out.println("\nNext row data:");
                System.out.println("ID: " + rs.getInt("id"));
                System.out.println("Name: " + rs.getString("name"));
            } else {
                System.out.println("\nNo next row after first.");
            }

            // 5. Move cursor absolutely to 2nd row (if exists)
            if (rs.absolute(2)) {
                System.out.println("\nAbsolute move to row 2:");
                System.out.println("ID: " + rs.getInt("id"));
                System.out.println("Name: " + rs.getString("name"));
            }

            // 6. Insert a new row with unique ID
            int newId = 1;
            if (rs.last()) {
                newId = rs.getInt("id") + 1;
            }
            rs.moveToInsertRow();
            rs.updateInt("id", newId);
            rs.updateString("name", "New Student");
            rs.insertRow();
            System.out.println("\nInserted new row with ID=" + newId + " and name='New Student'");

            // Move cursor back to a valid row before refresh
            if (rs.last()) {
                rs.refreshRow();
            }

            // 7. Iterate over all rows and print
            System.out.println("\nAll rows after insert and update:");
            rs.beforeFirst();
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") + ", Name: " + rs.getString("name"));
            }

            // 8. Delete the last row (move to last first)
            if (rs.last()) {
                System.out.println("\nDeleting last row: ID=" + rs.getInt("id"));
                rs.deleteRow();
            }

            // 9. Print all rows after delete
            System.out.println("\nAll rows after deleting last row:");
            rs.beforeFirst();
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") + ", Name: " + rs.getString("name"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
